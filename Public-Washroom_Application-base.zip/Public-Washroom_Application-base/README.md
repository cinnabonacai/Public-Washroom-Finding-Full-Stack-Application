# An interactive crowd sourced map to assist users in finding nearby restrooms



##To run, use yarn install to ensure dependency version consistency and then run yarn dev to start the server.
