/// <reference types="next" />
/// <reference types="next/types/global" />

declare module "cloudinary-react";

type YOLO = any;
